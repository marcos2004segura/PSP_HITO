package hito;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Cliente {

    private static final String DIRECCION_SERVIDOR = "localhost";
    private static final int PUERTO = 60000;

    public static void main(String[] args) {
        try (
            Socket socket = new Socket(DIRECCION_SERVIDOR, PUERTO);
            OutputStream salida = socket.getOutputStream();
            PrintWriter escritor = new PrintWriter(salida, true);
            InputStream entrada = socket.getInputStream();
            BufferedReader lector = new BufferedReader(new InputStreamReader(entrada));
				Scanner scanner = new Scanner(System.in)
        ) {
            System.out.print("Introduce la palabra clave para buscar libros: ");
            String palabraClave = scanner.nextLine();
            System.out.println("Enviando palabra clave: " + palabraClave);

            // Enviar palabra clave al servidor
            escritor.println(palabraClave);

            // Leer y mostrar la respuesta del servidor
            System.out.println("Respuesta del servidor:");
            String respuesta;
            while ((respuesta = lector.readLine()) != null) {
                System.out.println(respuesta);
            }

            System.out.println("Conexión con el servidor finalizada.");
        } catch (IOException e) {
            System.err.println("Error en el cliente: " + e.getMessage());
        }
    }
}

