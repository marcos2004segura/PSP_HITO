package hito;

import java.io.*;
import java.net.*;
import java.util.List;

public class Servidor {

    private static final int PUERTO = 60000;

    public static void main(String[] args) {
        AccesoDatos accesoDatos = new AccesoDatos();

        try (ServerSocket servidor = new ServerSocket(PUERTO)) {
            System.out.println("El servidor está escuchando en el puerto " + PUERTO);

            while (true) {
                Socket socket = servidor.accept();
                System.out.println("Cliente conectado.");

                new Thread(() -> manejarCliente(socket, accesoDatos)).start();
            }
        } catch (IOException e) {
            System.err.println("Error en el servidor: " + e.getMessage());
        }
    }

    private static void manejarCliente(Socket socket, AccesoDatos accesoDatos) {
        try (
            InputStream entrada = socket.getInputStream();
            BufferedReader lector = new BufferedReader(new InputStreamReader(entrada));
            OutputStream salida = socket.getOutputStream();
            PrintWriter escritor = new PrintWriter(salida, true)
        ) {
            System.out.println("Conexión establecida con el cliente.");

            // Leer palabra clave del cliente
            String palabraClave = lector.readLine();
            System.out.println("Palabra clave recibida: " + palabraClave);

            // Buscar en la base de datos
            List<String> resultados = accesoDatos.buscarLibros(palabraClave);

            // Enviar resultados al cliente
            if (resultados.isEmpty()) {
                escritor.println("No se encontraron libros relacionados con: " + palabraClave);
            } else {
                for (String resultado : resultados) {
                    escritor.println(resultado);
                }
            }

            System.out.println("Resultados enviados al cliente.");
        } catch (IOException e) {
            System.err.println("Error al manejar al cliente: " + e.getMessage());
        }
    }

}

