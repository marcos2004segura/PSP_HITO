package hito;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AccesoDatos {

    private static final String URL = "jdbc:mysql://localhost:3309/biblioteca";
    private static final String USUARIO = "root"; // Cambia si usas otro usuario
    private static final String CONTRASENA = ""; // Cambia si tienes contraseña

    public List<String> buscarLibros(String palabraClave) {
        List<String> resultados = new ArrayList<>();

        String consulta = "SELECT titulo, autor, precio FROM libros WHERE palabra_clave LIKE ?";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Cargar el controlador
            try (Connection conexion = DriverManager.getConnection(URL, USUARIO, CONTRASENA)) {
                System.out.println("Conexión exitosa con la base de datos.");

                PreparedStatement stmt = conexion.prepareStatement(consulta);
                stmt.setString(1, "%" + palabraClave + "%");
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    String titulo = rs.getString("titulo");
                    String autor = rs.getString("autor");
                    double precio = rs.getDouble("precio");

                    resultados.add(titulo + "; Autor: " + autor + "; Precio: " + precio);
                }
            }
        } catch (ClassNotFoundException e) {
            System.err.println("Error: Controlador JDBC no encontrado.");
        } catch (SQLException e) {
            System.err.println("Error al conectar con la base de datos: " + e.getMessage());
        }

        return resultados;
    }
}
